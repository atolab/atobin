#ifndef ZENOH_C_KONTIKI_NET_H
#define ZENOH_C_KONTIKI_NET_H

#include "contiki-net.h"
#include "sys/cc.h"

typedef struct tcp_socket z_socket_t;

#endif /* ZENOH_C_KONTIKI_NET_H */