#ifndef ZENOH_C_UNIX_NET_H_
#define ZENOH_C_UNIX_NET_H_

typedef int z_socket_t;

#endif /* ZENOH_C_UNIX_NET_H_ */
